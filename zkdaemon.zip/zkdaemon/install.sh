#!/usr/bin/env bash
# ZK-MC3-PANEL · node daemon installer
#
#   sudo bash install.sh <token> <panel-url>
#
# Runs the daemon as a systemd service so it survives a reboot and reconnects
# by itself. Everything it needs is already in this folder.
set -uo pipefail
cd "$(dirname "$0")"

TOKEN="${1:-}"
PANEL="${2:-}"
PORT=""  # unused; the daemon dials out, so it listens on nothing

if [ -z "$TOKEN" ]; then
  echo "Usage: sudo bash install.sh <token> <panel-url>" >&2
  echo "" >&2
  echo "  <token>      Copy it from the panel: Admin → Nodes → Add node." >&2
  echo "  <panel-url>  e.g. https://panel.example.com or http://203.0.113.5:31120" >&2
  echo "               Must be reachable FROM this machine (not 127.0.0.1)." >&2
  exit 1
fi

if ! command -v node >/dev/null 2>&1; then
  echo "Node.js is required (v20+). Install it, then re-run:" >&2
  echo "  curl -fsSL https://deb.nodesource.com/setup_20.x | sudo bash - && sudo apt install -y nodejs" >&2
  exit 1
fi

MAJOR="$(node -p 'process.versions.node.split(".")[0]')"
if [ "$MAJOR" -lt 20 ]; then
  echo "Node.js v$MAJOR is too old — the daemon needs v20 or newer." >&2
  exit 1
fi

echo "▸ Writing configuration"
node - "$TOKEN" "$PANEL" <<'NODE'
const fs = require("fs");
const [token, panel] = process.argv.slice(2);
const config = { panelUrl: panel || process.env.ZK_PANEL_URL || "", token, nodeName: "" };
if (!config.panelUrl) {
  console.error("A panel URL is required: sudo bash install.sh <token> <panel-url>");
  process.exit(1);
}
fs.writeFileSync("config.json", JSON.stringify(config, null, 2) + "\n", { mode: 0o600 });
NODE
[ $? -ne 0 ] && exit 1

echo "▸ Starting the daemon"
if command -v systemctl >/dev/null 2>&1 && [ -d /run/systemd/system ]; then
  cat >/etc/systemd/system/zkdaemon.service <<SERVICE
[Unit]
Description=ZK-MC3-PANEL node daemon
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory=$(pwd)
ExecStart=$(command -v node) $(pwd)/index.js
Restart=always
RestartSec=5
User=root

[Install]
WantedBy=multi-user.target
SERVICE
  systemctl daemon-reload
  systemctl enable zkdaemon >/dev/null 2>&1
  systemctl restart zkdaemon
  sleep 2
  if systemctl is-active --quiet zkdaemon; then
    echo "✔ Daemon running — check the panel, the node is online"
    echo "  journalctl -u zkdaemon -f   to watch it"
  else
    echo "✖ The daemon did not start. Run: journalctl -u zkdaemon -n 50" >&2
    exit 1
  fi
else
  echo "systemd not found — running in the background with nohup"
  (setsid nohup node index.js >daemon.log 2>&1 </dev/null &)
  sleep 2
  tail -5 daemon.log
fi
